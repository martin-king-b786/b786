<?php

$db = 'cl43-b786-form';
$u = 'root';
$p = '';

?>