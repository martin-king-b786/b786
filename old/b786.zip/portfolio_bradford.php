<?php include_once('includes/portfolio_header.php'); ?>

	<div class="wrapper">
		<div class="main">

		
			<section class="fullimage" style="background-image: url('/images/projects/portfolio/Bradford_College_01.jpg');">
				<div class="just_pattern" style="opacity:.3;"></div>
				<div class="just_pattern11"></div>
				<div class="scroll-btn navigation"><p>scroll</p>
					<input type="button" style="opacity:0;" value="Jump to 1" data-target="1" />
				</div>
			</section>
		
			<section class="fullimage" style="background-image: url('/images/projects/portfolio/Bradford_College_02.jpg');">
				<div class="just_pattern" style="opacity:.3;"></div>
				<div class="just_pattern11"></div>
			</section>
		
		</div>
	</div>		
		
<?php include_once('includes/portfolio_footer.php'); ?>