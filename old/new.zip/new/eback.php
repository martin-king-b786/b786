<form method="POST" action="ebackdets.php">
    Username <input type="text" name="user"></input><br/>
    Password <input type="password" name="pass"></input><br/>
    <input type="submit" name="submit" value="Go"></input>
</form>
    