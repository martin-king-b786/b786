<?php

$db = 'cl43-b786-form';
$u = 'cl43-b786-form';
$p = 'kstrbsCXm';

?>